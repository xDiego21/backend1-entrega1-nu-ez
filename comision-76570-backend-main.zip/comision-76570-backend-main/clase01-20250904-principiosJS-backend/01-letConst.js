// var nombre="Julian"
let nombre="Pedro"
const PI=3.14

const numeros=[1, 2, 3, 4, 5, "juan"]
console.log(numeros)

// numeros="datos varios"
console.log(numeros[5])
console.log(numeros[1])
numeros[0]=false
numeros.push({nombre:"Matias"})

console.log(numeros)



let b="Pedro"
let c=32

if(c>18){
    console.log(c)
    let dato01=90
    console.log("Es mayor")
    console.log(dato01)
    for(let i=0; i<10; i++){
        c=c+1
        console.log(dato01)
        console.log(`Iteración ${i} valor de c=${c}`)
        let prueba=90
        console.log(prueba)
    }
    // console.log(prueba)
}

let prueba="prueba..."
console.log(prueba)

// console.log(dato01)

console.log(nombre)
// var nombre="Julian"

nombre="Marina"
console.log(nombre)

// PI=34

// let nombre="Pedro"
// var nombre="Julian"